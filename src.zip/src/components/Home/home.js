import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import React, { useEffect } from "react";
import SideMenu from "../sidebar/SideMenu";

const Home = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = Cookies.get("jwt_token");
    if (token === undefined) {
      navigate("/");
    }
  });
  return (
    <>
      <div className="home_page">
        <SideMenu />
        <h1>Welcome to this Home page..!</h1>
      </div>
    </>
  );
};

export default Home;
