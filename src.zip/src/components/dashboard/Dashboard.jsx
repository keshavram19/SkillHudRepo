import React from "react";
import SideMenu from "../sidebar/SideMenu";

export default function Dashboard() {
  return (
    <>
      <SideMenu />
      <div>Dashboard</div>;
    </>
  );
}
