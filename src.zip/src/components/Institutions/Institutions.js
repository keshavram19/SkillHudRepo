import React from "react";
import SideMenu from "../sidebar/SideMenu";

export default function Institutions() {
  return (
    <>
      <SideMenu />
      <div>Institutions</div>
    </>
  );
}
