import React from "react";
import SideMenu from "../sidebar/SideMenu";

export default function Users() {
  return (
    <>
      <div>
        <SideMenu />
      </div>
      <div className="usertext">Users</div>
    </>
  );
}
