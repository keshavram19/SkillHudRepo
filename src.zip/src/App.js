import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Auths from "./components/Login/Login";
import Home from "./components/Home/home";
import SideMenu from "./components/sidebar/SideMenu";
import Users from "./components/users/Users";
import Institutions from "./components/Institutions/Institutions";
import Dashboard from "./components/dashboard/Dashboard";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route exact path="/" element={<Auths />} />
          <Route exact path="/home" element={<Home />} />
          <Route exact path="/Users" element={<Users />} />
          <Route exact path="/Institutions" element={<Institutions />} />
          <Route exact path="/dashboard" element={<Dashboard />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
